
#ifndef BLINKLICHT_H
#define BLINKLICHT_H

extern char c;

struct Test {
  char x;
  int  a;
}

void blinken ();

#endif
