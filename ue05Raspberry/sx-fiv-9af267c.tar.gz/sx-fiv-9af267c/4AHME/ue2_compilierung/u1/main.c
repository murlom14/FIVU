#include <stdio.h>

int main ()
{
   printf("Hallo\n");
   return 0;
}

