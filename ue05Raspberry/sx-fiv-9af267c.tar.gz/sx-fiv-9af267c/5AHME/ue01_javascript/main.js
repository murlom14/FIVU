console.log('Hallo, guten Morgen');
// console.log(jahr);
// console.log(monat);
var jahr = 2018;
var monat = "September";
var datum;
datum = monat + jahr;
console.log(datum);
