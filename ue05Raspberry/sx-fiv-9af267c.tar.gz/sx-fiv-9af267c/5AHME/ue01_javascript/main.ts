console.log('Hallo, guten Morgen');

// console.log(jahr);
// console.log(monat);

var jahr = 2018;
let monat = "September";
let datum : string;

datum = monat + jahr;

console.log(datum);


